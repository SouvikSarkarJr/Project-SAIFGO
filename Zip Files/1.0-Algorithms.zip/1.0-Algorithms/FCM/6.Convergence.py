# ==========================================================
# FUZZY C-MEANS (FCM) + CONVERGENCE CURVE ANALYSIS
# (ONE IMAGE)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Delivery.csv" #Change
n_clusters = 3
max_iter = 50
m = 2.0          # Fuzziness parameter
epsilon = 1e-5   # Convergence threshold

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

scaler = StandardScaler()
X = scaler.fit_transform(X)

n_samples, n_features = X.shape

# ==========================================================
# 🔹 3. MANUAL FCM (To Track Convergence)
# ==========================================================

np.random.seed(42)

# Initialize membership matrix randomly
U = np.random.dirichlet(np.ones(n_clusters), size=n_samples)

objective_history = []

for iteration in range(max_iter):

    # Compute centroids
    U_m = U ** m
    centroids = (U_m.T @ X) / np.sum(U_m.T, axis=1, keepdims=True)

    # Compute distances
    dist = np.linalg.norm(X[:, np.newaxis] - centroids, axis=2) + 1e-10

    # Compute objective function (Jm)
    J = np.sum((U ** m) * (dist ** 2))
    objective_history.append(J)

    # Update membership matrix
    new_U = np.zeros_like(U)

    for i in range(n_samples):
        for k in range(n_clusters):
            denominator = np.sum(
                (dist[i, k] / dist[i, :]) ** (2 / (m - 1))
            )
            new_U[i, k] = 1 / denominator

    # Check convergence
    if np.linalg.norm(new_U - U) < epsilon:
        print(f"Converged at iteration {iteration}")
        break

    U = new_U

# ==========================================================
# 🔹 4. PLOT CONVERGENCE CURVE
# ==========================================================

plt.figure()
plt.plot(range(1, len(objective_history) + 1), objective_history)
plt.xlabel("Iteration")
plt.ylabel("Objective Function (Jm)")
plt.title("FCM Convergence Curve (Placement Dataset)") # Change
plt.tight_layout()

output_file = "Placement_FCM_Convergence.jpg" # Change
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Convergence curve saved as: {output_file}")
