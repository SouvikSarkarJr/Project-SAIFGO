import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from tqdm import tqdm

# -----------------------------
# LOAD + PREPROCESS
# -----------------------------
def load_and_preprocess(file_path):
    df = pd.read_csv(file_path)

    num_cols = df.select_dtypes(include=[np.number]).columns
    cat_cols = df.select_dtypes(exclude=[np.number]).columns

    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown='ignore'), cat_cols)
    ])

    X = preprocessor.fit_transform(df)

    if hasattr(X, "toarray"):
        X = X.toarray()

    return X


# -----------------------------
# GENERAL TREND EXTRACTION (FAST)
# -----------------------------
def compute_general_trend(X):
    """
    Vectorized trend computation (much faster than loop)
    """
    # variance
    var = np.var(X, axis=0)

    # slope (vectorized)
    x_axis = np.arange(X.shape[0])
    x_mean = np.mean(x_axis)
    denom = np.sum((x_axis - x_mean) ** 2)

    slopes = []
    for i in tqdm(range(X.shape[1]), desc="Computing trends"):
        y = X[:, i]
        slope = np.sum((x_axis - x_mean) * (y - np.mean(y))) / denom
        slopes.append(slope)

    slopes = np.array(slopes)

    trends = var + np.abs(slopes)
    trends = trends / np.max(trends)

    return trends


# -----------------------------
# VALIDITY INDICES
# -----------------------------
def davies_bouldin_index(X, labels, centers):
    k = len(centers)
    clusters = [X[labels == i] for i in range(k)]

    S = np.array([
        np.mean(cdist(cluster, [centers[i]])) if len(cluster) > 0 else 0
        for i, cluster in enumerate(clusters)
    ])

    M = cdist(centers, centers)
    np.fill_diagonal(M, np.inf)

    R = (S[:, None] + S[None, :]) / M
    return np.mean(np.max(R, axis=1))


def dunn_index(X, labels):
    clusters = [X[labels == i] for i in np.unique(labels)]

    inter, intra = np.inf, 0

    for i in range(len(clusters)):
        if len(clusters[i]) > 1:
            intra = max(intra, np.max(cdist(clusters[i], clusters[i])))

        for j in range(i + 1, len(clusters)):
            inter = min(inter, np.min(cdist(clusters[i], clusters[j])))

    return inter / intra if intra != 0 else 0


def xie_beni_index(X, labels, centers):
    n = len(X)
    dist = cdist(X, centers)
    min_dist = np.min(dist, axis=1)

    numerator = np.sum(min_dist ** 2)

    center_dist = cdist(centers, centers)
    np.fill_diagonal(center_dist, np.inf)

    denominator = n * (np.min(center_dist) ** 2)
    return numerator / denominator


# -----------------------------
# FCM (FAST + STABLE)
# -----------------------------
class FuzzyCMeans:
    def __init__(self, n_clusters=3, m=2, max_iter=100, tol=1e-4):
        self.k = n_clusters
        self.m = m
        self.max_iter = max_iter
        self.tol = tol

    def fit(self, X):
        n = X.shape[0]

        # Random init
        idx = np.random.choice(n, self.k, replace=False)
        centers = X[idx]

        for _ in tqdm(range(self.max_iter), desc="FCM Optimization"):
            dist = cdist(X, centers) + 1e-8

            power = 2 / (self.m - 1)
            inv_dist = 1.0 / dist
            temp = inv_dist ** power
            U = temp / np.sum(temp, axis=1, keepdims=True)

            U_m = U ** self.m
            new_centers = (U_m.T @ X) / np.sum(U_m.T, axis=1, keepdims=True)

            if np.linalg.norm(new_centers - centers) < self.tol:
                break

            centers = new_centers

        labels = np.argmax(U, axis=1)
        return labels, centers


# -----------------------------
# TREND + FCM
# -----------------------------
class Trend_FCM:
    def __init__(self, n_clusters=3):
        self.k = n_clusters

    def fit(self, X):
        print("Extracting trends...")
        weights = compute_general_trend(X)

        X_weighted = X * weights

        print("Running FCM...")
        fcm = FuzzyCMeans(n_clusters=self.k)
        labels, centers = fcm.fit(X_weighted)

        self.labels = labels
        self.centers = centers

        return labels, centers


# -----------------------------
# MAIN
# -----------------------------
if __name__ == "__main__":
    file_path = "/Users/souviksarkarjr./Downloads/IFGO/Dataset/Wave.csv"

    print("Loading data...")
    X = load_and_preprocess(file_path)

    model = Trend_FCM(n_clusters=3)
    labels, centers = model.fit(X)

    print("\nCalculating metrics...")

    sil = silhouette_score(X, labels)
    db = davies_bouldin_index(X, labels, centers)
    dunn = dunn_index(X, labels)
    xb = xie_beni_index(X, labels, centers)
    ch = calinski_harabasz_score(X, labels)

    print("\nFinal Results (Trend + FCM):")
    print(f"Silhouette Score      : {sil:.4f}")
    print(f"Davies-Bouldin Index : {db:.4f}")
    print(f"Dunn Index           : {dunn:.4f}")
    print(f"Xie-Beni Index       : {xb:.4f}")
    print(f"Calinski-Harabasz    : {ch:.4f}")