# ==========================================================
# K-MEANS + INDEPENDENT T-TEST + JPG GRAPH
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from scipy.stats import ttest_ind
import os

# ==========================================================
# 🔹 1. DATASET
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Wave.csv"   # CHANGE IF NEEDED
n_clusters = 3

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found in current folder.")

df = pd.read_csv(file_path)

# Keep only numeric columns
X = df.select_dtypes(include=[np.number])

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

# Standardize
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==========================================================
# 🔹 3. APPLY K-MEANS
# ==========================================================
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
labels = kmeans.fit_predict(X_scaled)

df["Cluster"] = labels

print("\n================ CLUSTERING DONE ================")
print(f"Number of Clusters: {n_clusters}")
print(df["Cluster"].value_counts())
print("=================================================\n")

# ==========================================================
# 🔹 4. INDEPENDENT T-TEST (Welch's T-Test)
# ==========================================================
clusters = np.unique(labels)

if len(clusters) < 2:
    raise ValueError("Need at least 2 clusters for T-Test.")

cluster_0 = X_scaled[labels == clusters[0]]
cluster_1 = X_scaled[labels == clusters[1]]

features = X.columns.tolist()
p_values = []

print("============= T-TEST RESULTS =============")

for i in range(len(features)):
    stat, p_value = ttest_ind(
        cluster_0[:, i],
        cluster_1[:, i],
        equal_var=False   # Welch’s version (safer)
    )

    p_values.append(p_value)

    print(f"\nFeature: {features[i]}")
    print(f"T-Statistic = {stat:.4f}")
    print(f"P-value     = {p_value:.6f}")

    if p_value < 0.05:
        print("Significant Difference")
    else:
        print("Not Significant")

print("==========================================\n")

# ==========================================================
# 🔹 5. GENERATE LINE GRAPH
# ==========================================================
plt.figure()

plt.plot(features, p_values, marker='o')
plt.axhline(y=0.05)

plt.xticks(rotation=45)
plt.title("T-Test (Cluster 0 vs Cluster 1)")
plt.xlabel("Features (Wave Dataset)")
plt.ylabel("P-values")

plt.tight_layout()

# Save as JPG
output_file = "KMeans.jpg"   # CHANGE IF NEEDED
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Graph saved successfully as: {output_file}")