# ==========================================================
# K-MEANS + KRUSKAL-WALLIS + VARGHA-DELANY A12 (ONE IMAGE)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from scipy.stats import kruskal
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Iris.csv" #change
n_clusters = 3

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==========================================================
# 🔹 3. K-MEANS
# ==========================================================
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
labels = kmeans.fit_predict(X_scaled)

clusters = np.unique(labels)
features = X.columns.tolist()

# ==========================================================
# 🔹 4. DEFINE VARGHA-DELANY A12
# ==========================================================
def vargha_delaney_a12(x, y):
    m = len(x)
    n = len(y)
    ranks = np.concatenate([x, y])
    rank = ranks.argsort().argsort() + 1
    r1 = np.sum(rank[:m])
    A12 = (r1 / m - (m + 1) / 2) / n
    return A12

# ==========================================================
# 🔹 5. COMPUTE EFFECT SIZES (Only Significant Features)
# ==========================================================
effect_matrices = []

for i in range(len(features)):

    cluster_data = []
    for c in clusters:
        cluster_values = X_scaled[labels == c, i]
        cluster_data.append(cluster_values)

    stat, p_value = kruskal(*cluster_data)

    if p_value < 0.05:

        size = len(clusters)
        matrix = np.zeros((size, size))

        for a in range(size):
            for b in range(size):
                if a != b:
                    matrix[a, b] = vargha_delaney_a12(
                        cluster_data[a],
                        cluster_data[b]
                    )

        effect_matrices.append((features[i], matrix))

# ==========================================================
# 🔹 6. GENERATE ONE SINGLE IMAGE
# ==========================================================
if len(effect_matrices) == 0:
    print("No significant features found.")
else:

    rows = len(effect_matrices)
    plt.figure(figsize=(6, 4 * rows))

    for idx, (feature_name, matrix) in enumerate(effect_matrices):
        plt.subplot(rows, 1, idx + 1)
        plt.imshow(matrix)
        plt.colorbar()
        plt.title(f"Vargha-Delaney A12 Effect Size (Iris Dataset)- {feature_name}") #change
        plt.xticks(range(len(clusters)), [f"C{c}" for c in clusters])
        plt.yticks(range(len(clusters)), [f"C{c}" for c in clusters])

    plt.tight_layout()
    output_file = "combined_vargha_delaney_A12.jpg" #change
    plt.savefig(output_file, format="jpg")
    plt.close()

    print(f"Single image saved as: {output_file}")
