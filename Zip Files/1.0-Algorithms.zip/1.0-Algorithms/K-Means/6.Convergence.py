# ==========================================================
# K-MEANS + CONVERGENCE CURVE ANALYSIS (ONE IMAGE)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Placement.csv" #Change
n_clusters = 3
max_iter = 50

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

scaler = StandardScaler()
X = scaler.fit_transform(X)

# ==========================================================
# 🔹 3. MANUAL K-MEANS (To Track Convergence)
# ==========================================================

# Random centroid initialization
np.random.seed(42)
centroids = X[np.random.choice(X.shape[0], n_clusters, replace=False)]

inertia_history = []

for iteration in range(max_iter):

    # Assign clusters
    distances = np.linalg.norm(X[:, np.newaxis] - centroids, axis=2)
    labels = np.argmin(distances, axis=1)

    # Compute new centroids
    new_centroids = np.array([
        X[labels == k].mean(axis=0) for k in range(n_clusters)
    ])

    # Compute inertia (SSE)
    inertia = 0
    for k in range(n_clusters):
        cluster_points = X[labels == k]
        inertia += np.sum((cluster_points - centroids[k])**2)

    inertia_history.append(inertia)

    # Stop if converged
    if np.allclose(centroids, new_centroids):
        print(f"Converged at iteration {iteration}")
        break

    centroids = new_centroids

# ==========================================================
# 🔹 4. PLOT CONVERGENCE CURVE
# ==========================================================

plt.figure()
plt.plot(range(1, len(inertia_history)+1), inertia_history)
plt.xlabel("Iteration")
plt.ylabel("Inertia (SSE)")
plt.title("K-Means Convergence Curve (Placement Dataset)") #Change
plt.tight_layout()

output_file = "Placement.jpg" #Change
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Convergence curve saved as: {output_file}")



