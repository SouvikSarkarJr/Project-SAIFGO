import os
from PIL import Image, ImageDraw, ImageFont


def save_under_size(image, output_path, max_size_mb=50, dpi=300):
    """Save image under a target file size by reducing JPEG quality."""
    quality = 95
    max_bytes = max_size_mb * 1024 * 1024

    while quality > 10:
        image.save(
            output_path,
            format="JPEG",
            quality=quality,
            optimize=True,
            dpi=(dpi, dpi)
        )

        if os.path.getsize(output_path) <= max_bytes:
            print(f"Saved with quality={quality}")
            return

        quality -= 5

    print("Saved with minimum quality")


def resize_to_ieee(image, column="double", dpi=300):
    """
    Resize image to IEEE standard width.
    single column = 3.5 inches
    double column = 7.16 inches
    """

    width_inch = 3.5 if column == "single" else 7.16
    target_width_px = int(width_inch * dpi)

    w, h = image.size
    scale = target_width_px / w
    new_height = int(h * scale)

    return image.resize((target_width_px, new_height), Image.LANCZOS)


def create_collage(
    image_folder,
    output_path="flowchart.jpg",
    columns=2,
    rows=1,
    spacing=20,
    bg_color=(255, 255, 255),
    border_color=(0, 0, 0),
    border_width=3,
    text_height=150,
    font_size=70
):

    image_files = sorted([
        f for f in os.listdir(image_folder)
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))
    ])

    if len(image_files) != columns * rows:
        raise ValueError(f"Exactly {columns * rows} images required for {columns}×{rows} layout.")

    images = []
    for file in image_files:
        img = Image.open(os.path.join(image_folder, file)).convert("RGB")
        images.append((img, file))

    base_width, base_height = images[0][0].size

    resized_images = []
    for img, name in images:
        img = img.resize((base_width, base_height), Image.LANCZOS)
        resized_images.append((img, name))

    collage_width = columns * base_width + (columns + 1) * spacing
    collage_height = rows * (base_height + text_height) + (rows + 1) * spacing

    collage = Image.new("RGB", (collage_width, collage_height), bg_color)
    draw = ImageDraw.Draw(collage)

    font_path = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"

    for index, (img, name) in enumerate(resized_images):

        row = index // columns
        col = index % columns

        x = spacing + col * (base_width + spacing)
        y = spacing + row * (base_height + text_height + spacing)

        collage.paste(img, (x, y))

        draw.rectangle(
            [x, y, x + base_width, y + base_height],
            outline=border_color,
            width=border_width
        )

        # IEEE style label
        clean_name = f"({chr(97+index)}) {os.path.splitext(name)[0]}"

        max_text_width = base_width - 30
        current_font_size = font_size

        while True:
            font = ImageFont.truetype(font_path, current_font_size)
            text_bbox = draw.textbbox((0, 0), clean_name, font=font)
            text_width = text_bbox[2] - text_bbox[0]

            if text_width <= max_text_width or current_font_size <= 40:
                break

            current_font_size -= 2

        text_height_actual = text_bbox[3] - text_bbox[1]

        text_x = x + (base_width - text_width) // 2
        text_y = y + base_height + (text_height - text_height_actual) // 2

        draw.text((text_x, text_y), clean_name, fill=(0, 0, 0), font=font)

    collage = resize_to_ieee(collage, column="double", dpi=300)

    save_under_size(collage, output_path, max_size_mb=50)

    print(f"Collage saved as {output_path}")


# RUN
create_collage(
    image_folder="/Users/souviksarkarjr./Documents/IFGO/Real_Life_Application/Banking/result",
    output_path="/Users/souviksarkarjr./Documents/IFGO/Real_Life_Application/Banking/Credit-Card.jpg",
    columns=2,
    rows=1,
    text_height=150,
    font_size=70
)